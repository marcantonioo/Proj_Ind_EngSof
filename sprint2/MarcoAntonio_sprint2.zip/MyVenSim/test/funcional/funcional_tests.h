 
#ifndef FUNCIONAL_TESTS_H
#define FUNCIONAL_TESTS_H


void exponentialFuncionalTest();


void logisticalFuncionalTest();


void complexFuncionalTest();

#endif // FUNCIONAL_TESTS_H